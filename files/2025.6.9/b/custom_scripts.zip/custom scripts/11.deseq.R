library(DESeq2)
library(tidyverse)
library(EnhancedVolcano)

# create folders
if (dir.exists("./3.analysis/8.spreadsheets/")==FALSE){
  dir.create("./3.analysis/8.spreadsheets/")
}
if (dir.exists("./3.analysis/8.spreadsheets/5.summary/")==FALSE){
  dir.create("./3.analysis/8.spreadsheets/5.summary/")
}
if (dir.exists("./3.analysis/9.plots/")==FALSE){
  dir.create("./3.analysis/9.plots/")
}
if (dir.exists("./3.analysis/9.plots/8.differential_mutation/")==FALSE){
  dir.create("./3.analysis/9.plots/8.differential_mutation/")
}
if (dir.exists("./3.analysis/9.plots/8.differential_mutation/pdf/")==FALSE){
  dir.create("./3.analysis/9.plots/8.differential_mutation/pdf/")
}
if (dir.exists("./3.analysis/9.plots/8.differential_mutation/jpg/")==FALSE){
  dir.create("./3.analysis/9.plots/8.differential_mutation/jpg/")
}

################################################################################

list <- read.csv("./3.analysis/8.spreadsheets/5.summary/list.csv", header = FALSE)
colnames(list) <- c("Sample", "Group", "Sample_short", "Group_short")
position <- read.csv("./3.analysis/8.spreadsheets/5.summary/position.csv", header = TRUE)

################################################################################

# C12_50C
C12_50Cs <- filter(list, grepl("C12-50C", list$Sample_short))

ctrl_1 <- filter(C12_50Cs, grepl("ctrl1", C12_50Cs$Sample_short))
ctrl_1 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", ctrl_1$Sample), header = TRUE)
ctrl_1_mut_count <- ctrl_1$Mut_count
ctrl_1_depth <- ctrl_1$Depth

ctrl_2 <- filter(C12_50Cs, grepl("ctrl2", C12_50Cs$Sample_short))
ctrl_2 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", ctrl_2$Sample), header = TRUE)
ctrl_2_mut_count <- ctrl_2$Mut_count
ctrl_2_depth <- ctrl_2$Depth

treat_1 <- filter(C12_50Cs, grepl("treat1", C12_50Cs$Sample_short))
treat_1 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", treat_1$Sample), header = TRUE)
treat_1_mut_count <- treat_1$Mut_count
treat_1_depth <- treat_1$Depth

treat_2 <- filter(C12_50Cs, grepl("treat2", C12_50Cs$Sample_short))
treat_2 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", treat_2$Sample), header = TRUE)
treat_2_mut_count <- treat_2$Mut_count
treat_2_depth <- treat_2$Depth

counts <- cbind(ctrl_1_mut_count, ctrl_2_mut_count, treat_1_mut_count, treat_2_mut_count)
rownames(counts) <- paste0("position_", position$Position_in_arc_plot)
colnames(counts) <- c("Control_Rep1","Control_Rep2","Treat_Rep1","Treat_Rep2")

coverage <- cbind(ctrl_1_depth, ctrl_2_depth, treat_1_depth, treat_2_depth)
rownames(coverage) <- paste0("position_", position$Position_in_arc_plot)
colnames(coverage) <- c("Control_Rep1","Control_Rep2","Treat_Rep1","Treat_Rep2")

coldata <- data.frame(
  row.names = colnames(counts),
  condition = c("Control", "Control", "Treatment", "Treatment")
)

dds <- DESeqDataSetFromMatrix(countData = counts,
                              colData = coldata,
                              design = ~ condition)
assays(dds)[["offset"]] <- log(coverage)
dds <- DESeq(dds)
res_mat <- as.data.frame(results(dds))
res_mat <- cbind(position$Position_in_arc_plot, position$Ref_base, res_mat)
colnames(res_mat)[1] <- "Position_in_SL5_arc_plot"
colnames(res_mat)[2] <- "Ref_base"
res_mat$Position_in_SL5_arc_plot <- paste0("position_", res_mat$Position_in_SL5_arc_plot)
res_mat$Ref_base <- toupper(position$Ref_base)
position$Ref_base <- gsub("T", "U", position$Ref_base)
write.table(res_mat, file=paste0("./3.analysis/8.spreadsheets/5.summary/C12_50C_DEseq2.csv"), sep=",", row.names = FALSE)

p <- EnhancedVolcano(res_mat,
                     title = 'Differential mutation analysis: C12+C34 vs C12 at 50°C',
                     lab = rownames(res_mat),
                     x = 'log2FoldChange',
                     y = 'padj', 
                     xlim = c(-3.5,3.5),
                     ylim = c(0,118), 
                     ylab = expression(-Log[10](italic(p.adj))),
                     pCutoff = 1e-18,
                     FCcutoff = 0.5,
                     pointSize = 3.5,
                     caption = paste0(nrow(res_mat), ' positions in the amplicon\n(Each group has 2 replicates)'),
                     captionLabSize = 12,
                     drawConnectors = TRUE,
                     lengthConnectors = unit(0.02, "npc"),
                     widthConnectors = 0.5,
                     arrowheads = FALSE
)
ggsave("./3.analysis/9.plots/8.differential_mutation/pdf/C12_50C_volcano.pdf", plot = p, width = 9, height = 8, units = "in", dpi = 1200)

################################################################################

# C30_50C
C30_50Cs <- filter(list, grepl("C30-50C", list$Sample_short))

ctrl_1 <- filter(C30_50Cs, grepl("ctrl1", C30_50Cs$Sample_short))
ctrl_1 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", ctrl_1$Sample), header = TRUE)
ctrl_1_mut_count <- ctrl_1$Mut_count
ctrl_1_depth <- ctrl_1$Depth

ctrl_2 <- filter(C30_50Cs, grepl("ctrl2", C30_50Cs$Sample_short))
ctrl_2 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", ctrl_2$Sample), header = TRUE)
ctrl_2_mut_count <- ctrl_2$Mut_count
ctrl_2_depth <- ctrl_2$Depth

treat_1 <- filter(C30_50Cs, grepl("treat1", C30_50Cs$Sample_short))
treat_1 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", treat_1$Sample), header = TRUE)
treat_1_mut_count <- treat_1$Mut_count
treat_1_depth <- treat_1$Depth

treat_2 <- filter(C30_50Cs, grepl("treat2", C30_50Cs$Sample_short))
treat_2 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", treat_2$Sample), header = TRUE)
treat_2_mut_count <- treat_2$Mut_count
treat_2_depth <- treat_2$Depth

counts <- cbind(ctrl_1_mut_count, ctrl_2_mut_count, treat_1_mut_count, treat_2_mut_count)
rownames(counts) <- paste0("position_", position$Position_in_arc_plot)
colnames(counts) <- c("Control_Rep1","Control_Rep2","Treat_Rep1","Treat_Rep2")

coverage <- cbind(ctrl_1_depth, ctrl_2_depth, treat_1_depth, treat_2_depth)
rownames(coverage) <- paste0("position_", position$Position_in_arc_plot)
colnames(coverage) <- c("Control_Rep1","Control_Rep2","Treat_Rep1","Treat_Rep2")

coldata <- data.frame(
  row.names = colnames(counts),
  condition = c("Control", "Control", "Treatment", "Treatment")
)

dds <- DESeqDataSetFromMatrix(countData = counts,
                              colData = coldata,
                              design = ~ condition)
assays(dds)[["offset"]] <- log(coverage)
dds <- DESeq(dds)
res_mat <- as.data.frame(results(dds))
res_mat <- cbind(position$Position_in_arc_plot, position$Ref_base, res_mat)
colnames(res_mat)[1] <- "Position_in_SL5_arc_plot"
colnames(res_mat)[2] <- "Ref_base"
res_mat$Position_in_SL5_arc_plot <- paste0("position_", res_mat$Position_in_SL5_arc_plot)
res_mat$Ref_base <- toupper(position$Ref_base)
position$Ref_base <- gsub("T", "U", position$Ref_base)
write.table(res_mat, file=paste0("./3.analysis/8.spreadsheets/5.summary/C30_50C_DEseq2.csv"), sep=",", row.names = FALSE)

p <- EnhancedVolcano(res_mat,
                     title = 'Differential mutation analysis: C30+C34 vs C30 at 50°C',
                     lab = rownames(res_mat),
                     x = 'log2FoldChange',
                     y = 'padj', 
                     xlim = c(-3.5,3.5),
                     ylim = c(0,80), 
                     ylab = expression(-Log[10](italic(p.adj))),
                     pCutoff = 1e-17,
                     FCcutoff = 0.5,
                     pointSize = 3.5,
                     caption = paste0(nrow(res_mat), ' positions in the amplicon\n(Each group has 2 replicates)'),
                     captionLabSize = 12,
                     drawConnectors = TRUE,
                     lengthConnectors = unit(0.02, "npc"),
                     widthConnectors = 0.5,
                     arrowheads = FALSE
)
ggsave("./3.analysis/9.plots/8.differential_mutation/pdf/C30_50C_volcano.pdf", plot = p, width = 9, height = 8, units = "in", dpi = 1200)

################################################################################

# C12_60C
C12_60Cs <- filter(list, grepl("C12-60C", list$Sample_short))

ctrl_1 <- filter(C12_60Cs, grepl("ctrl1", C12_60Cs$Sample_short))
ctrl_1 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", ctrl_1$Sample), header = TRUE)
ctrl_1_mut_count <- ctrl_1$Mut_count
ctrl_1_depth <- ctrl_1$Depth

ctrl_2 <- filter(C12_60Cs, grepl("ctrl2", C12_60Cs$Sample_short))
ctrl_2 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", ctrl_2$Sample), header = TRUE)
ctrl_2_mut_count <- ctrl_2$Mut_count
ctrl_2_depth <- ctrl_2$Depth

treat_1 <- filter(C12_60Cs, grepl("treat1", C12_60Cs$Sample_short))
treat_1 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", treat_1$Sample), header = TRUE)
treat_1_mut_count <- treat_1$Mut_count
treat_1_depth <- treat_1$Depth

treat_2 <- filter(C12_60Cs, grepl("treat2", C12_60Cs$Sample_short))
treat_2 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", treat_2$Sample), header = TRUE)
treat_2_mut_count <- treat_2$Mut_count
treat_2_depth <- treat_2$Depth

counts <- cbind(ctrl_1_mut_count, ctrl_2_mut_count, treat_1_mut_count, treat_2_mut_count)
rownames(counts) <- paste0("position_", position$Position_in_arc_plot)
colnames(counts) <- c("Control_Rep1","Control_Rep2","Treat_Rep1","Treat_Rep2")

coverage <- cbind(ctrl_1_depth, ctrl_2_depth, treat_1_depth, treat_2_depth)
rownames(coverage) <- paste0("position_", position$Position_in_arc_plot)
colnames(coverage) <- c("Control_Rep1","Control_Rep2","Treat_Rep1","Treat_Rep2")

coldata <- data.frame(
  row.names = colnames(counts),
  condition = c("Control", "Control", "Treatment", "Treatment")
)

dds <- DESeqDataSetFromMatrix(countData = counts,
                              colData = coldata,
                              design = ~ condition)
assays(dds)[["offset"]] <- log(coverage)
dds <- DESeq(dds)
res_mat <- as.data.frame(results(dds))
res_mat <- cbind(position$Position_in_arc_plot, position$Ref_base, res_mat)
colnames(res_mat)[1] <- "Position_in_SL5_arc_plot"
colnames(res_mat)[2] <- "Ref_base"
res_mat$Position_in_SL5_arc_plot <- paste0("position_", res_mat$Position_in_SL5_arc_plot)
res_mat$Ref_base <- toupper(position$Ref_base)
position$Ref_base <- gsub("T", "U", position$Ref_base)
write.table(res_mat, file=paste0("./3.analysis/8.spreadsheets/5.summary/C12_60C_DEseq2.csv"), sep=",", row.names = FALSE)

p <- EnhancedVolcano(res_mat,
                     title = 'Differential mutation analysis: C12+C34 vs C12 at 60°C',
                     lab = rownames(res_mat),
                     x = 'log2FoldChange',
                     y = 'pvalue', 
                     xlim = c(-3.5,3.5),
                     ylim = c(0,80), 
                     ylab = expression(-Log[10](italic(p.adj))),
                     pCutoff = 1e-18,
                     FCcutoff = 0.5,
                     pointSize = 3.5,
                     caption = paste0(nrow(res_mat), ' positions in the amplicon\n(Each group has 2 replicates)'),
                     captionLabSize = 12,
                     drawConnectors = TRUE,
                     lengthConnectors = unit(0.01, "npc"),
                     widthConnectors = 0.5,
                     arrowheads = FALSE
)
ggsave("./3.analysis/9.plots/8.differential_mutation/pdf/C12_60C_volcano.pdf", plot = p, width = 9, height = 8, units = "in", dpi = 1200)

################################################################################

# C30_60C
C30_60Cs <- filter(list, grepl("C30-60C", list$Sample_short))

ctrl_1 <- filter(C30_60Cs, grepl("ctrl1", C30_60Cs$Sample_short))
ctrl_1 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", ctrl_1$Sample), header = TRUE)
ctrl_1_mut_count <- ctrl_1$Mut_count
ctrl_1_depth <- ctrl_1$Depth

ctrl_2 <- filter(C30_60Cs, grepl("ctrl2", C30_60Cs$Sample_short))
ctrl_2 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", ctrl_2$Sample), header = TRUE)
ctrl_2_mut_count <- ctrl_2$Mut_count
ctrl_2_depth <- ctrl_2$Depth

treat_1 <- filter(C30_60Cs, grepl("treat1", C30_60Cs$Sample_short))
treat_1 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", treat_1$Sample), header = TRUE)
treat_1_mut_count <- treat_1$Mut_count
treat_1_depth <- treat_1$Depth

treat_2 <- filter(C30_60Cs, grepl("treat2", C30_60Cs$Sample_short))
treat_2 <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", treat_2$Sample), header = TRUE)
treat_2_mut_count <- treat_2$Mut_count
treat_2_depth <- treat_2$Depth

counts <- cbind(ctrl_1_mut_count, ctrl_2_mut_count, treat_1_mut_count, treat_2_mut_count)
rownames(counts) <- paste0("position_", position$Position_in_arc_plot)
colnames(counts) <- c("Control_Rep1","Control_Rep2","Treat_Rep1","Treat_Rep2")

coverage <- cbind(ctrl_1_depth, ctrl_2_depth, treat_1_depth, treat_2_depth)
rownames(coverage) <- paste0("position_", position$Position_in_arc_plot)
colnames(coverage) <- c("Control_Rep1","Control_Rep2","Treat_Rep1","Treat_Rep2")

coldata <- data.frame(
  row.names = colnames(counts),
  condition = c("Control", "Control", "Treatment", "Treatment")
)

dds <- DESeqDataSetFromMatrix(countData = counts,
                              colData = coldata,
                              design = ~ condition)
assays(dds)[["offset"]] <- log(coverage)
dds <- DESeq(dds)
res_mat <- as.data.frame(results(dds))
res_mat <- cbind(position$Position_in_arc_plot, position$Ref_base, res_mat)
colnames(res_mat)[1] <- "Position_in_SL5_arc_plot"
colnames(res_mat)[2] <- "Ref_base"
res_mat$Position_in_SL5_arc_plot <- paste0("position_", res_mat$Position_in_SL5_arc_plot)
res_mat$Ref_base <- toupper(position$Ref_base)
position$Ref_base <- gsub("T", "U", position$Ref_base)
write.table(res_mat, file=paste0("./3.analysis/8.spreadsheets/5.summary/C30_60C_DEseq2.csv"), sep=",", row.names = FALSE)

p <- EnhancedVolcano(res_mat,
                     title = 'Differential mutation analysis: C30+C34 vs C30 at 60°C',
                     lab = rownames(res_mat),
                     x = 'log2FoldChange',
                     y = 'pvalue', 
                     xlim = c(-3.5,3.5),
                     ylim = c(0,80), 
                     ylab = expression(-Log[10](italic(p.adj))),
                     pCutoff = 1e-17,
                     FCcutoff = 0.5,
                     pointSize = 3.5,
                     caption = paste0(nrow(res_mat), ' positions in the amplicon\n(Each group has 2 replicates)'),
                     captionLabSize = 12,
                     drawConnectors = TRUE,
                     lengthConnectors = unit(0.01, "npc"),
                     widthConnectors = 0.5,
                     arrowheads = FALSE
)
ggsave("./3.analysis/9.plots/8.differential_mutation/pdf/C30_60C_volcano.pdf", plot = p, width = 9, height = 8, units = "in", dpi = 1200)

################################################################################

library(tidyverse)
library(ggplot2)
library(expss)

csvs <- list.files(path = "./3.analysis/8.spreadsheets/5.summary/", pattern = '*_DEseq2.csv', full.names = TRUE)
colors <- c("A" = "#1F77B4", "C" = "#FF7F0E", "G" = "#2CA02C", "U" = "#D62728")

################################################################################

# C12_50C
csv <- csvs[grep("C12_50C", csvs)]
df <- read.csv(csv, header = TRUE)
df$Position_in_SL5_arc_plot <- gsub("position_", "", df$Position_in_SL5_arc_plot)
df$Position_in_SL5_arc_plot <- as.numeric(df$Position_in_SL5_arc_plot)
df$Ref_base <- toupper(df$Ref_base)
df$Ref_base <- gsub("T", "U", df$Ref_base)

p <- df %>%
  ggplot(aes(x = Position_in_SL5_arc_plot, y = -log10(padj), fill = Ref_base)) +
  geom_col(width = 0.8) +
  scale_fill_manual(values = colors) +
  geom_hline(yintercept = 18, linetype = "dashed", color = "red") +
  scale_x_continuous(breaks = seq(25, 300, by = 25)) + 
  ylim(-10, 120) +
  labs(title = "Differential mutation analysis: C12+C34 vs C12 at 50°C",
       y = "-log10(adjusted p-value)", x = "Position") +
  annotate("text", x = 169, y = 0, label = "bulge G", vjust = +4) +
  annotate("text", x = 169, y = 0, label = "|", vjust = +2, fontface = "bold") +
  theme_minimal()

filename <- gsub(".csv", "_padj", basename(csv))

ggsave(paste0("./3.analysis/9.plots/8.differential_mutation/jpg/", filename, ".jpg"),
       plot = p, width = 15, height = 5, units = "in", dpi = 1200)
ggsave(paste0("./3.analysis/9.plots/8.differential_mutation/pdf/", filename, ".pdf"),
       plot = p, width = 15, height = 5, units = "in", dpi = 1200)

################################################################################

# C30_50C
csv <- csvs[grep("C30_50C", csvs)]
df <- read.csv(csv, header = TRUE)
df$Position_in_SL5_arc_plot <- gsub("position_", "", df$Position_in_SL5_arc_plot)
df$Position_in_SL5_arc_plot <- as.numeric(df$Position_in_SL5_arc_plot)
df$Ref_base <- toupper(df$Ref_base)
df$Ref_base <- gsub("T", "U", df$Ref_base)

p <- df %>%
  ggplot(aes(x = Position_in_SL5_arc_plot, y = -log10(padj), fill = Ref_base)) +
  geom_col(width = 0.8) +
  scale_fill_manual(values = colors) +
  geom_hline(yintercept = 17, linetype = "dashed", color = "red") +
  scale_x_continuous(breaks = seq(25, 300, by = 25)) + 
  ylim(-10, 50) +
  labs(title = "Differential mutation analysis: C30+C34 vs C30 at 50°C",
       y = "-log10(adjusted p-value)", x = "Position") +
  annotate("text", x = 169, y = 0, label = "bulge G", vjust = +4) +
  annotate("text", x = 169, y = 0, label = "|", vjust = +2, fontface = "bold") +
  theme_minimal()

filename <- gsub(".csv", "_padj", basename(csv))

ggsave(paste0("./3.analysis/9.plots/8.differential_mutation/jpg/", filename, ".jpg"),
       plot = p, width = 15, height = 5, units = "in", dpi = 1200)
ggsave(paste0("./3.analysis/9.plots/8.differential_mutation/pdf/", filename, ".pdf"),
       plot = p, width = 15, height = 5, units = "in", dpi = 1200)

################################################################################

# C12_60C
csv <- csvs[grep("C12_60C", csvs)]
df <- read.csv(csv, header = TRUE)
df$Position_in_SL5_arc_plot <- gsub("position_", "", df$Position_in_SL5_arc_plot)
df$Position_in_SL5_arc_plot <- as.numeric(df$Position_in_SL5_arc_plot)
df$Ref_base <- toupper(df$Ref_base)
df$Ref_base <- gsub("T", "U", df$Ref_base)

p <- df %>%
  ggplot(aes(x = Position_in_SL5_arc_plot, y = -log10(padj), fill = Ref_base)) +
  geom_col(width = 0.8) +
  scale_fill_manual(values = colors) +
  geom_hline(yintercept = 18, linetype = "dashed", color = "red") +
  scale_x_continuous(breaks = seq(25, 300, by = 25)) + 
  ylim(-10, 80) +
  labs(title = "Differential mutation analysis: C12+C34 vs C12 at 60°C",
       y = "-log10(adjusted p-value)", x = "Position") +
  annotate("text", x = 169, y = 0, label = "bulge G", vjust = +4) +
  annotate("text", x = 169, y = 0, label = "|", vjust = +2, fontface = "bold") +
  theme_minimal()

filename <- gsub(".csv", "_padj", basename(csv))

ggsave(paste0("./3.analysis/9.plots/8.differential_mutation/jpg/", filename, ".jpg"),
       plot = p, width = 15, height = 5, units = "in", dpi = 1200)
ggsave(paste0("./3.analysis/9.plots/8.differential_mutation/pdf/", filename, ".pdf"),
       plot = p, width = 15, height = 5, units = "in", dpi = 1200)

################################################################################

# C30_60C
csv <- csvs[grep("C30_60C", csvs)]
df <- read.csv(csv, header = TRUE)
df$Position_in_SL5_arc_plot <- gsub("position_", "", df$Position_in_SL5_arc_plot)
df$Position_in_SL5_arc_plot <- as.numeric(df$Position_in_SL5_arc_plot)
df$Ref_base <- toupper(df$Ref_base)
df$Ref_base <- gsub("T", "U", df$Ref_base)

p <- df %>%
  ggplot(aes(x = Position_in_SL5_arc_plot, y = -log10(padj), fill = Ref_base)) +
  geom_col(width = 0.8) +
  scale_fill_manual(values = colors) +
  geom_hline(yintercept = 17, linetype = "dashed", color = "red") +
  scale_x_continuous(breaks = seq(25, 300, by = 25)) + 
  ylim(-10, 80) +
  labs(title = "Differential mutation analysis: C30+C34 vs C30 at 60°C",
       y = "-log10(adjusted p-value)", x = "Position") +
  annotate("text", x = 169, y = 0, label = "bulge G", vjust = +4) +
  annotate("text", x = 169, y = 0, label = "|", vjust = +2, fontface = "bold") +
  theme_minimal()

filename <- gsub(".csv", "_padj", basename(csv))

ggsave(paste0("./3.analysis/9.plots/8.differential_mutation/jpg/", filename, ".jpg"),
       plot = p, width = 15, height = 5, units = "in", dpi = 1200)
ggsave(paste0("./3.analysis/9.plots/8.differential_mutation/pdf/", filename, ".pdf"),
       plot = p, width = 15, height = 5, units = "in", dpi = 1200)

