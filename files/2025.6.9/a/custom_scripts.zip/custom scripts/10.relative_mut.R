library(tidyverse)
library(ggplot2)
library(expss)

# create folder
if (dir.exists("./3.analysis/8.spreadsheets/")==FALSE){
  dir.create("./3.analysis/8.spreadsheets/")
}
if (dir.exists("./3.analysis/8.spreadsheets/4.mean_summary/")==FALSE){
  dir.create("./3.analysis/8.spreadsheets/4.mean_summary/")
}
if (dir.exists("./3.analysis/9.plots/")==FALSE){
  dir.create("./3.analysis/9.plots/")
}
if (dir.exists("./3.analysis/9.plots/6.relative_mut/")==FALSE){
  dir.create("./3.analysis/9.plots/6.relative_mut/")
}
if (dir.exists("./3.analysis/9.plots/7.relative_mut_summary/")==FALSE){
  dir.create("./3.analysis/9.plots/7.relative_mut_summary/")
}
if (dir.exists("./3.analysis/9.plots/7.relative_mut_summary/pdf/")==FALSE){
  dir.create("./3.analysis/9.plots/7.relative_mut_summary/pdf/")
}
if (dir.exists("./3.analysis/9.plots/7.relative_mut_summary/jpg/")==FALSE){
  dir.create("./3.analysis/9.plots/7.relative_mut_summary/jpg/")
}

################################################################################

# calculate mean mut percentage
csvs <- list.files(path='./3.analysis/8.spreadsheets/3.mpileup_parse', pattern='*.mpileup.csv', full.names = TRUE)
list <- read.csv("./3.analysis/8.spreadsheets/4.mean_summary/list.csv", header = FALSE)
colnames(list) <- c("Sample", "Group")
groups <- unique(list$Group)

for (group in groups) {
  
  replicate <- filter(list, Group == group)
  replicate <- replicate$Sample
  
  merge <- add_columns(read.csv(paste0("./3.analysis/8.spreadsheets/3.mpileup_parse/", replicate[[1]]), header = TRUE), 
                       read.csv(paste0("./3.analysis/8.spreadsheets/3.mpileup_parse/", replicate[[2]]), header = TRUE), 
                       by=c("Region", "Position", "Ref_base"))
  merge <- mutate(merge, Mean_mut_percentage = round((Mut_percentage + Mut_percentage_1 ) / 2, 4))
  merge <- mutate(merge, Total_depth = Depth + Depth_1)
  merge <- mutate(merge, Total_mut = Mut_count + Mut_count_1)
  
  merge <- merge[c("Region", "Position", "Ref_base", "Total_depth", "Total_mut", "Mean_mut_percentage")]
  merge$Mean_mut_percentage[merge$Mean_mut_percentage < 0] <- 0
  
  write.table(merge, file=paste0("./3.analysis/8.spreadsheets/4.mean_summary/", group, ".mean.csv"), sep=",", row.names = FALSE)
  
}

################################################################################

# Project-1_40C
csvs <- list.files(path='./3.analysis/8.spreadsheets/4.mean_summary', pattern='*.mean.csv', full.names = TRUE)
SL5_40Cs <- csvs[grepl("40C-15min", csvs)]
internal_ctrl <- read.csv("./3.analysis/8.spreadsheets/4.mean_summary/01_live-cell_DMSO_40C-15min_Mn.mean.csv", header = TRUE)
internal_ctrl <- internal_ctrl[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
internal_ctrl <- filter(internal_ctrl, Region == "SARS-CoV2-5UTR-Amplicon-short-trimmed+3")
internal_ctrl$Mean_mut_percentage[internal_ctrl$Mean_mut_percentage < 0] <- 0
internal_ctrl$Ref_base <- toupper(internal_ctrl$Ref_base)
internal_ctrl$Ref_base <- gsub("T", "U", internal_ctrl$Ref_base)
colors <- c("A" = "#1F77B4", "C" = "#FF7F0E", "G" = "#2CA02C", "U" = "#D62728")
summary <- c("avg_A","avg_C","avg_G","avg_U")

for (SL5_40C in SL5_40Cs) {
  
  df <- read.csv(SL5_40C, header = TRUE)
  df <- filter(df, Region == "SARS-CoV2-5UTR-Amplicon-short-trimmed+3")
  df$Mean_mut_percentage[df$df$Mean_mut_percentage < 0] <- 0
  df$Ref_base <- toupper(df$Ref_base)
  df$Ref_base <- gsub("T", "U", df$Ref_base)
  region <- unique(df$Region)
  df <- df[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
  
  difference <- add_columns(df, internal_ctrl, by=c("Region", "Position", "Ref_base"))
  colnames(difference) <- c("Region", "Position", "Ref_base", "Mut_percentage", "Mut_percentage_ctrl")
  
  difference <- mutate(difference, Difference = Mut_percentage - Mut_percentage_ctrl)
  
  a <- filter(difference, Ref_base == "A")
  a <- round(mean(a$Difference),4)
  c <- filter(difference, Ref_base == "C")
  c <- round(mean(c$Difference),4)
  g <- filter(difference, Ref_base == "G")
  g <- round(mean(g$Difference),4)
  u <- filter(difference, Ref_base == "U")
  u <- round(mean(u$Difference),4)
  summary <- data.frame(summary,c(a,c,g,u))
  
  filename <- gsub("./3.analysis/8.spreadsheets/4.mean_summary/","",SL5_40C)
  filename <- gsub("_", "-", filename)
  filename <- gsub(".mean.csv","",filename)
  filename <- paste0(filename, "_", region)
  
  p <- ggplot(difference, aes(x=Position, y=Difference, fill=Ref_base)) +
    geom_col(width = 0.8) +
    scale_fill_manual(values = colors) +
    scale_x_continuous(breaks = seq(0, max(df$Position), by = 50)) +
    coord_cartesian(ylim = c(-1, 2)) +
    labs(title = paste0(filename, " (relative to DMSO-Mn-Ctrl)"), x = "Position", y = "Mutation (%)") +
    theme_minimal() + 
    theme(plot.title = element_text(hjust = 0.5))
  #ggsave(paste0("./3.analysis/9.plots/6.relative_mut/", filename, ".pdf"), plot = p, width = 15, height = 3, units = "in", dpi = 1200)
  ggsave(paste0("./3.analysis/9.plots/6.relative_mut/", filename, ".jpg"), plot = p, width = 15, height = 3, units = "in", dpi = 1200)
}
names <- gsub(".mean.csv", "", basename(SL5_40Cs))
colnames(summary) <- c("Base", names)
sum40 <- summary

################################################################################

# Project-1_50C
csvs <- list.files(path='./3.analysis/8.spreadsheets/4.mean_summary', pattern='*.mean.csv', full.names = TRUE)
SL5_50Cs <- csvs[grepl("50C-15min", csvs)]
internal_ctrl <- read.csv("./3.analysis/8.spreadsheets/4.mean_summary/04_live-cell_DMSO_50C-15min_Mn.mean.csv", header = TRUE)
internal_ctrl <- internal_ctrl[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
internal_ctrl <- filter(internal_ctrl, Region == "SARS-CoV2-5UTR-Amplicon-short-trimmed+3")
internal_ctrl$Mean_mut_percentage[internal_ctrl$Mean_mut_percentage < 0] <- 0
internal_ctrl$Ref_base <- toupper(internal_ctrl$Ref_base)
internal_ctrl$Ref_base <- gsub("T", "U", internal_ctrl$Ref_base)
colors <- c("A" = "#1F77B4", "C" = "#FF7F0E", "G" = "#2CA02C", "U" = "#D62728")
summary <- c("avg_A","avg_C","avg_G","avg_U")

for (SL5_50C in SL5_50Cs) {
  
  df <- read.csv(SL5_50C, header = TRUE)
  df <- filter(df, Region == "SARS-CoV2-5UTR-Amplicon-short-trimmed+3")
  df$Mean_mut_percentage[df$df$Mean_mut_percentage < 0] <- 0
  df$Ref_base <- toupper(df$Ref_base)
  df$Ref_base <- gsub("T", "U", df$Ref_base)
  region <- unique(df$Region)
  df <- df[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
  
  difference <- add_columns(df, internal_ctrl, by=c("Region", "Position", "Ref_base"))
  colnames(difference) <- c("Region", "Position", "Ref_base", "Mut_percentage", "Mut_percentage_ctrl")
  
  difference <- mutate(difference, Difference = Mut_percentage - Mut_percentage_ctrl)
  
  a <- filter(difference, Ref_base == "A")
  a <- round(mean(a$Difference),4)
  c <- filter(difference, Ref_base == "C")
  c <- round(mean(c$Difference),4)
  g <- filter(difference, Ref_base == "G")
  g <- round(mean(g$Difference),4)
  u <- filter(difference, Ref_base == "U")
  u <- round(mean(u$Difference),4)
  summary <- data.frame(summary,c(a,c,g,u))
  
  filename <- gsub("./3.analysis/8.spreadsheets/4.mean_summary/","",SL5_50C)
  filename <- gsub("_", "-", filename)
  filename <- gsub(".mean.csv","",filename)
  filename <- paste0(filename, "_", region)
  
  p <- ggplot(difference, aes(x=Position, y=Difference, fill=Ref_base)) +
    geom_col(width = 0.8) +
    scale_fill_manual(values = colors) +
    scale_x_continuous(breaks = seq(0, max(df$Position), by = 50)) +
    coord_cartesian(ylim = c(-1, 2)) +
    labs(title = paste0(filename, " (relative to DMSO-Mn-Ctrl)"), x = "Position", y = "Mutation (%)") +
    theme_minimal() + 
    theme(plot.title = element_text(hjust = 0.5))
  #ggsave(paste0("./3.analysis/9.plots/6.relative_mut/", filename, ".pdf"), plot = p, width = 15, height = 3, units = "in", dpi = 1200)
  ggsave(paste0("./3.analysis/9.plots/6.relative_mut/", filename, ".jpg"), plot = p, width = 15, height = 3, units = "in", dpi = 1200)
}
names <- gsub(".mean.csv", "", basename(SL5_50Cs))
colnames(summary) <- c("Base", names)
sum50 <- summary

################################################################################

# Project-1_60C
csvs <- list.files(path='./3.analysis/8.spreadsheets/4.mean_summary', pattern='*.mean.csv', full.names = TRUE)
SL5_60Cs <- csvs[grepl("60C-15min", csvs)]
internal_ctrl <- read.csv("./3.analysis/8.spreadsheets/4.mean_summary/07_live-cell_DMSO_60C-15min_Mn.mean.csv", header = TRUE)
internal_ctrl <- internal_ctrl[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
internal_ctrl <- filter(internal_ctrl, Region == "SARS-CoV2-5UTR-Amplicon-short-trimmed+3")
internal_ctrl$Mean_mut_percentage[internal_ctrl$Mean_mut_percentage < 0] <- 0
internal_ctrl$Ref_base <- toupper(internal_ctrl$Ref_base)
internal_ctrl$Ref_base <- gsub("T", "U", internal_ctrl$Ref_base)
colors <- c("A" = "#1F77B4", "C" = "#FF7F0E", "G" = "#2CA02C", "U" = "#D62728")
summary <- c("avg_A","avg_C","avg_G","avg_U")

for (SL5_60C in SL5_60Cs) {
  
  df <- read.csv(SL5_60C, header = TRUE)
  df <- filter(df, Region == "SARS-CoV2-5UTR-Amplicon-short-trimmed+3")
  df$Mean_mut_percentage[df$df$Mean_mut_percentage < 0] <- 0
  df$Ref_base <- toupper(df$Ref_base)
  df$Ref_base <- gsub("T", "U", df$Ref_base)
  region <- unique(df$Region)
  df <- df[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
  
  difference <- add_columns(df, internal_ctrl, by=c("Region", "Position", "Ref_base"))
  colnames(difference) <- c("Region", "Position", "Ref_base", "Mut_percentage", "Mut_percentage_ctrl")
  
  difference <- mutate(difference, Difference = Mut_percentage - Mut_percentage_ctrl)
  
  a <- filter(difference, Ref_base == "A")
  a <- round(mean(a$Difference),4)
  c <- filter(difference, Ref_base == "C")
  c <- round(mean(c$Difference),4)
  g <- filter(difference, Ref_base == "G")
  g <- round(mean(g$Difference),4)
  u <- filter(difference, Ref_base == "U")
  u <- round(mean(u$Difference),4)
  summary <- data.frame(summary,c(a,c,g,u))
  
  filename <- gsub("./3.analysis/8.spreadsheets/4.mean_summary/","",SL5_60C)
  filename <- gsub("_", "-", filename)
  filename <- gsub(".mean.csv","",filename)
  filename <- paste0(filename, "_", region)
  
  p <- ggplot(difference, aes(x=Position, y=Difference, fill=Ref_base)) +
    geom_col(width = 0.8) +
    scale_fill_manual(values = colors) +
    scale_x_continuous(breaks = seq(0, max(df$Position), by = 50)) +
    coord_cartesian(ylim = c(-1, 2)) +
    labs(title = paste0(filename, " (relative to DMSO-Mn-Ctrl)"), x = "Position", y = "Mutation (%)") +
    theme_minimal() + 
    theme(plot.title = element_text(hjust = 0.5))
  #ggsave(paste0("./3.analysis/9.plots/6.relative_mut/", filename, ".pdf"), plot = p, width = 15, height = 3, units = "in", dpi = 1200)
  ggsave(paste0("./3.analysis/9.plots/6.relative_mut/", filename, ".jpg"), plot = p, width = 15, height = 3, units = "in", dpi = 1200)
}
names <- gsub(".mean.csv", "", basename(SL5_60Cs))
colnames(summary) <- c("Base", names)
sum60 <- summary

################################################################################

# Project-1_70C
csvs <- list.files(path='./3.analysis/8.spreadsheets/4.mean_summary', pattern='*.mean.csv', full.names = TRUE)
SL5_70Cs <- csvs[grepl("70C-15min", csvs)]
internal_ctrl <- read.csv("./3.analysis/8.spreadsheets/4.mean_summary/10_live-cell_DMSO_70C-15min_Mn.mean.csv", header = TRUE)
internal_ctrl <- internal_ctrl[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
internal_ctrl <- filter(internal_ctrl, Region == "SARS-CoV2-5UTR-Amplicon-short-trimmed+3")
internal_ctrl$Mean_mut_percentage[internal_ctrl$Mean_mut_percentage < 0] <- 0
internal_ctrl$Ref_base <- toupper(internal_ctrl$Ref_base)
internal_ctrl$Ref_base <- gsub("T", "U", internal_ctrl$Ref_base)
colors <- c("A" = "#1F77B4", "C" = "#FF7F0E", "G" = "#2CA02C", "U" = "#D62728")
summary <- c("avg_A","avg_C","avg_G","avg_U")

for (SL5_70C in SL5_70Cs) {
  
  df <- read.csv(SL5_70C, header = TRUE)
  df <- filter(df, Region == "SARS-CoV2-5UTR-Amplicon-short-trimmed+3")
  df$Mean_mut_percentage[df$df$Mean_mut_percentage < 0] <- 0
  df$Ref_base <- toupper(df$Ref_base)
  df$Ref_base <- gsub("T", "U", df$Ref_base)
  region <- unique(df$Region)
  df <- df[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
  
  difference <- add_columns(df, internal_ctrl, by=c("Region", "Position", "Ref_base"))
  colnames(difference) <- c("Region", "Position", "Ref_base", "Mut_percentage", "Mut_percentage_ctrl")
  
  difference <- mutate(difference, Difference = Mut_percentage - Mut_percentage_ctrl)
  
  a <- filter(difference, Ref_base == "A")
  a <- round(mean(a$Difference),4)
  c <- filter(difference, Ref_base == "C")
  c <- round(mean(c$Difference),4)
  g <- filter(difference, Ref_base == "G")
  g <- round(mean(g$Difference),4)
  u <- filter(difference, Ref_base == "U")
  u <- round(mean(u$Difference),4)
  summary <- data.frame(summary,c(a,c,g,u))
  
  filename <- gsub("./3.analysis/8.spreadsheets/4.mean_summary/","",SL5_70C)
  filename <- gsub("_", "-", filename)
  filename <- gsub(".mean.csv","",filename)
  filename <- paste0(filename, "_", region)
  
  p <- ggplot(difference, aes(x=Position, y=Difference, fill=Ref_base)) +
    geom_col(width = 0.8) +
    scale_fill_manual(values = colors) +
    scale_x_continuous(breaks = seq(0, max(df$Position), by = 50)) +
    coord_cartesian(ylim = c(-1, 2)) +
    labs(title = paste0(filename, " (relative to DMSO-Mn-Ctrl)"), x = "Position", y = "Mutation (%)") +
    theme_minimal() + 
    theme(plot.title = element_text(hjust = 0.5))
  #ggsave(paste0("./3.analysis/9.plots/6.relative_mut/", filename, ".pdf"), plot = p, width = 15, height = 3, units = "in", dpi = 1200)
  ggsave(paste0("./3.analysis/9.plots/6.relative_mut/", filename, ".jpg"), plot = p, width = 15, height = 3, units = "in", dpi = 1200)
}
names <- gsub(".mean.csv", "", basename(SL5_70Cs))
colnames(summary) <- c("Base", names)
sum70 <- summary

################################################################################

# Project-1_80C
csvs <- list.files(path='./3.analysis/8.spreadsheets/4.mean_summary', pattern='*.mean.csv', full.names = TRUE)
SL5_80Cs <- csvs[grepl("80C-15min", csvs)]
internal_ctrl <- read.csv("./3.analysis/8.spreadsheets/4.mean_summary/13_live-cell_DMSO_80C-15min_Mn.mean.csv", header = TRUE)
internal_ctrl <- internal_ctrl[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
internal_ctrl <- filter(internal_ctrl, Region == "SARS-CoV2-5UTR-Amplicon-short-trimmed+3")
internal_ctrl$Mean_mut_percentage[internal_ctrl$Mean_mut_percentage < 0] <- 0
internal_ctrl$Ref_base <- toupper(internal_ctrl$Ref_base)
internal_ctrl$Ref_base <- gsub("T", "U", internal_ctrl$Ref_base)
colors <- c("A" = "#1F77B4", "C" = "#FF7F0E", "G" = "#2CA02C", "U" = "#D62728")
summary <- c("avg_A","avg_C","avg_G","avg_U")

for (SL5_80C in SL5_80Cs) {
  
  df <- read.csv(SL5_80C, header = TRUE)
  df <- filter(df, Region == "SARS-CoV2-5UTR-Amplicon-short-trimmed+3")
  df$Mean_mut_percentage[df$df$Mean_mut_percentage < 0] <- 0
  df$Ref_base <- toupper(df$Ref_base)
  df$Ref_base <- gsub("T", "U", df$Ref_base)
  region <- unique(df$Region)
  df <- df[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
  
  difference <- add_columns(df, internal_ctrl, by=c("Region", "Position", "Ref_base"))
  colnames(difference) <- c("Region", "Position", "Ref_base", "Mut_percentage", "Mut_percentage_ctrl")
  
  difference <- mutate(difference, Difference = Mut_percentage - Mut_percentage_ctrl)
  
  a <- filter(difference, Ref_base == "A")
  a <- round(mean(a$Difference),4)
  c <- filter(difference, Ref_base == "C")
  c <- round(mean(c$Difference),4)
  g <- filter(difference, Ref_base == "G")
  g <- round(mean(g$Difference),4)
  u <- filter(difference, Ref_base == "U")
  u <- round(mean(u$Difference),4)
  summary <- data.frame(summary,c(a,c,g,u))
  
  filename <- gsub("./3.analysis/8.spreadsheets/4.mean_summary/","",SL5_80C)
  filename <- gsub("_", "-", filename)
  filename <- gsub(".mean.csv","",filename)
  filename <- paste0(filename, "_", region)
  
  p <- ggplot(difference, aes(x=Position, y=Difference, fill=Ref_base)) +
    geom_col(width = 0.8) +
    scale_fill_manual(values = colors) +
    scale_x_continuous(breaks = seq(0, max(df$Position), by = 50)) +
    coord_cartesian(ylim = c(-1, 2)) +
    labs(title = paste0(filename, " (relative to DMSO-Mn-Ctrl)"), x = "Position", y = "Mutation (%)") +
    theme_minimal() + 
    theme(plot.title = element_text(hjust = 0.5))
  #ggsave(paste0("./3.analysis/9.plots/6.relative_mut/", filename, ".pdf"), plot = p, width = 15, height = 3, units = "in", dpi = 1200)
  ggsave(paste0("./3.analysis/9.plots/6.relative_mut/", filename, ".jpg"), plot = p, width = 15, height = 3, units = "in", dpi = 1200)
}
names <- gsub(".mean.csv", "", basename(SL5_80Cs))
colnames(summary) <- c("Base", names)
sum80 <- summary

################################################################################

# plot summary
summary <- add_columns(sum40, sum50, by = "Base")
summary <- add_columns(summary, sum60, by = "Base")
summary <- add_columns(summary, sum70, by = "Base")
summary <- add_columns(summary, sum80, by = "Base")
summary_long <- pivot_longer(summary, cols = 2:ncol(summary), names_to = "Group", values_to = "Value")
summary <- t(summary)
colnames(summary) <- summary[1, ]
summary <- summary[-1, ] 
summary <- as.data.frame(summary)
summary <- summary %>% rownames_to_column("Group")
write.table(summary, file=paste0("./3.analysis/8.spreadsheets/4.mean_summary/base.mean.csv"), sep=",", row.names = FALSE)

colors <- c("avg_A" = "#1F77B4", "avg_C" = "#FF7F0E", "avg_G" = "#2CA02C", "avg_U" = "#D62728")
p <- ggplot(summary_long, aes(x = Group, y = Value, fill = Base)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.5), width = 0.5) +
  scale_fill_manual(values = colors) +
  coord_cartesian(ylim = c(-0.5, 1)) +
  theme_minimal() +
  labs(title = "Relative mutation rate summary",
       x = NULL, y = "Mutation Rate (%)") +
  theme(
    plot.title = element_text(hjust = 0.5),
    axis.text.x = element_text(angle = 65, hjust = 1),
    axis.title.x = element_text(margin = margin(t = 10))
  )
ggsave("./3.analysis/9.plots/7.relative_mut_summary/pdf/relative_mutation_rate_base_summary.pdf",
       plot = p, width = 12, height = 5, units = "in", dpi = 1200)
ggsave("./3.analysis/9.plots/7.relative_mut_summary/jpg/relative_mutation_rate_base_summary.jpg",
       plot = p, width = 12, height = 5, units = "in", dpi = 1200)


