library(tidyverse)
library(ggplot2)
library(expss)
library(cowplot)

# create folders
if (dir.exists("./3.analysis/9.plots/5.replicate_plot/")==FALSE){
  dir.create("./3.analysis/9.plots/5.replicate_plot/")
}

# combine replicates
csvs <- list.files(path='./3.analysis/8.spreadsheets/3.mpileup_parse', pattern='*.mpileup.csv', full.names = TRUE)
list <- read.csv("./3.analysis/8.spreadsheets/4.mean_summary/list.csv", header = FALSE)
colnames(list) <- c("Sample", "Group")
groups <- unique(list$Group)


# list to store plots
plot_list <- list()

# plot
for (i in seq_along(groups)) {
  group <- groups[[i]]
  
  replicate <- filter(list, Group == group)
  replicate <- replicate$Sample
  
  df1 <- read.csv(paste0("./3.analysis/8.spreadsheets/3.mpileup_parse/", replicate[[1]]))
  df2 <- read.csv(paste0("./3.analysis/8.spreadsheets/3.mpileup_parse/", replicate[[2]]))
  df1 <- mutate(df1, Mut_percentage = Mut_percentage + 0.1)
  df2 <- mutate(df2, Mut_percentage = Mut_percentage + 0.1)
  df3 <- as.data.frame(cbind(df1$Mut_percentage, df2$Mut_percentage))
  colnames(df3) <- c("Replicate_1", "Replicate_2")
  
  p <- ggplot(df3, aes(x = Replicate_1, y = Replicate_2)) +
    geom_point(shape = 21, color = "blue", fill = NA, size = 2, stroke = 0.5) +
    geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "red") +
    scale_x_log10() +
    scale_y_log10() +
    labs(
      title = paste("Replicate Comparison:", group),
      x = "Replicate-1",
      y = "Replicate-2"
    ) +
    theme_minimal()
  
  # Save individual plot
  ggsave(paste0("./3.analysis/9.plots/5.replicate_plot/", group, ".jpg"), plot = p, width = 7, height = 7, units = "in", dpi = 1200)
  
  # Add to list
  plot_list[[i]] <- p
}

# Combine all plots into one
combined_plot <- plot_grid(plotlist = plot_list, ncol = 5, align = 'hv', labels = LETTERS[1:length(plot_list)])
ggsave("./3.analysis/9.plots/5.replicate_plot/combined_plots.pdf", plot = combined_plot, width = 30, height = 2.4 * ceiling(length(plot_list)/2), units = "in", dpi = 1200)

# cleanup
rm(list = ls())