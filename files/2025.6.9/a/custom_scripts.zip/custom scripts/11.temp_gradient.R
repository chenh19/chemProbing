library(tidyverse)
library(ggplot2)
library(expss)

################################################################################

# calculate net mut percentage
csvs <- list.files(path='./3.analysis/8.spreadsheets/5.summary/', pattern='*.mpileup.csv', full.names = TRUE)
list <- read.csv("./3.analysis/8.spreadsheets/5.summary/list.csv", header = FALSE)
colnames(list) <- c("Sample", "Group")
samples <- unique(list$Sample)
groups <- unique(list$Group)

SL5_40Cs <- filter(list, grepl("40C-15min", list$Group))
internal_ctrl <- read.csv("./3.analysis/8.spreadsheets/5.summary/01_live-cell_DMSO_40C-15min_Mn.mean.csv", header = TRUE)
internal_ctrl <- internal_ctrl[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
internal_ctrl$Mean_mut_percentage[internal_ctrl$Mean_mut_percentage < 0] <- 0
internal_ctrl$Ref_base <- toupper(internal_ctrl$Ref_base)
internal_ctrl$Ref_base <- gsub("T", "U", internal_ctrl$Ref_base)

summary <- c("A","C","G","U")

for (SL5_40C in SL5_40Cs$Sample) {
  
  sample <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", SL5_40C), header = TRUE)
  sample <- sample[c("Region", "Position", "Ref_base", "Mut_percentage")]
  sample$Mut_percentage[sample$Mut_percentage < 0] <- 0
  sample$Ref_base <- toupper(sample$Ref_base)
  sample$Ref_base <- gsub("T", "U", sample$Ref_base)
  
  difference <- add_columns(sample, internal_ctrl, by=c("Region", "Position", "Ref_base"))
  colnames(difference) <- c("Region", "Position", "Ref_base", "Mut_percentage", "Mut_percentage_ctrl")
  difference <- mutate(difference, Difference = Mut_percentage - Mut_percentage_ctrl)
  
  a <- filter(difference, Ref_base == "A")
  a <- round(mean(a$Difference),4)
  c <- filter(difference, Ref_base == "C")
  c <- round(mean(c$Difference),4)
  g <- filter(difference, Ref_base == "G")
  g <- round(mean(g$Difference),4)
  u <- filter(difference, Ref_base == "U")
  u <- round(mean(u$Difference),4)
  summary <- data.frame(summary,c(a,c,g,u))

}
names <- basename(SL5_40Cs$Group)
colnames(summary) <- c("Base", names)
write.table(summary, file=paste0("./3.analysis/8.spreadsheets/5.summary/SL5_40C.csv"), sep=",", row.names = FALSE)
sum40 <- summary

################################################################################

# calculate net mut percentage
csvs <- list.files(path='./3.analysis/8.spreadsheets/5.summary/', pattern='*.mpileup.csv', full.names = TRUE)
list <- read.csv("./3.analysis/8.spreadsheets/5.summary/list.csv", header = FALSE)
colnames(list) <- c("Sample", "Group")
samples <- unique(list$Sample)
groups <- unique(list$Group)

SL5_50Cs <- filter(list, grepl("50C-15min", list$Group))
internal_ctrl <- read.csv("./3.analysis/8.spreadsheets/5.summary/04_live-cell_DMSO_50C-15min_Mn.mean.csv", header = TRUE)
internal_ctrl <- internal_ctrl[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
internal_ctrl$Mean_mut_percentage[internal_ctrl$Mean_mut_percentage < 0] <- 0
internal_ctrl$Ref_base <- toupper(internal_ctrl$Ref_base)
internal_ctrl$Ref_base <- gsub("T", "U", internal_ctrl$Ref_base)

summary <- c("A","C","G","U")

for (SL5_50C in SL5_50Cs$Sample) {
  
  sample <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", SL5_50C), header = TRUE)
  sample <- sample[c("Region", "Position", "Ref_base", "Mut_percentage")]
  sample$Mut_percentage[sample$Mut_percentage < 0] <- 0
  sample$Ref_base <- toupper(sample$Ref_base)
  sample$Ref_base <- gsub("T", "U", sample$Ref_base)
  
  difference <- add_columns(sample, internal_ctrl, by=c("Region", "Position", "Ref_base"))
  colnames(difference) <- c("Region", "Position", "Ref_base", "Mut_percentage", "Mut_percentage_ctrl")
  difference <- mutate(difference, Difference = Mut_percentage - Mut_percentage_ctrl)
  
  a <- filter(difference, Ref_base == "A")
  a <- round(mean(a$Difference),4)
  c <- filter(difference, Ref_base == "C")
  c <- round(mean(c$Difference),4)
  g <- filter(difference, Ref_base == "G")
  g <- round(mean(g$Difference),4)
  u <- filter(difference, Ref_base == "U")
  u <- round(mean(u$Difference),4)
  summary <- data.frame(summary,c(a,c,g,u))
  
}
names <- basename(SL5_50Cs$Group)
colnames(summary) <- c("Base", names)
write.table(summary, file=paste0("./3.analysis/8.spreadsheets/5.summary//SL5_50C.csv"), sep=",", row.names = FALSE)
sum50 <- summary

################################################################################

# calculate net mut percentage
csvs <- list.files(path='./3.analysis/8.spreadsheets/5.summary/', pattern='*.mpileup.csv', full.names = TRUE)
list <- read.csv("./3.analysis/8.spreadsheets/5.summary/list.csv", header = FALSE)
colnames(list) <- c("Sample", "Group")
samples <- unique(list$Sample)
groups <- unique(list$Group)

SL5_60Cs <- filter(list, grepl("60C-15min", list$Group))
internal_ctrl <- read.csv("./3.analysis/8.spreadsheets/5.summary/07_live-cell_DMSO_60C-15min_Mn.mean.csv", header = TRUE)
internal_ctrl <- internal_ctrl[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
internal_ctrl$Mean_mut_percentage[internal_ctrl$Mean_mut_percentage < 0] <- 0
internal_ctrl$Ref_base <- toupper(internal_ctrl$Ref_base)
internal_ctrl$Ref_base <- gsub("T", "U", internal_ctrl$Ref_base)

summary <- c("A","C","G","U")

for (SL5_60C in SL5_60Cs$Sample) {
  
  sample <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", SL5_60C), header = TRUE)
  sample <- sample[c("Region", "Position", "Ref_base", "Mut_percentage")]
  sample$Mut_percentage[sample$Mut_percentage < 0] <- 0
  sample$Ref_base <- toupper(sample$Ref_base)
  sample$Ref_base <- gsub("T", "U", sample$Ref_base)
  
  difference <- add_columns(sample, internal_ctrl, by=c("Region", "Position", "Ref_base"))
  colnames(difference) <- c("Region", "Position", "Ref_base", "Mut_percentage", "Mut_percentage_ctrl")
  difference <- mutate(difference, Difference = Mut_percentage - Mut_percentage_ctrl)
  
  a <- filter(difference, Ref_base == "A")
  a <- round(mean(a$Difference),4)
  c <- filter(difference, Ref_base == "C")
  c <- round(mean(c$Difference),4)
  g <- filter(difference, Ref_base == "G")
  g <- round(mean(g$Difference),4)
  u <- filter(difference, Ref_base == "U")
  u <- round(mean(u$Difference),4)
  summary <- data.frame(summary,c(a,c,g,u))
  
}
names <- basename(SL5_60Cs$Group)
colnames(summary) <- c("Base", names)
write.table(summary, file=paste0("./3.analysis/8.spreadsheets/5.summary/SL5_60C.csv"), sep=",", row.names = FALSE)
sum60 <- summary

################################################################################

# calculate net mut percentage
csvs <- list.files(path='./3.analysis/8.spreadsheets/5.summary/', pattern='*.mpileup.csv', full.names = TRUE)
list <- read.csv("./3.analysis/8.spreadsheets/5.summary/list.csv", header = FALSE)
colnames(list) <- c("Sample", "Group")
samples <- unique(list$Sample)
groups <- unique(list$Group)

SL5_70Cs <- filter(list, grepl("70C-15min", list$Group))
internal_ctrl <- read.csv("./3.analysis/8.spreadsheets/5.summary/10_live-cell_DMSO_70C-15min_Mn.mean.csv", header = TRUE)
internal_ctrl <- internal_ctrl[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
internal_ctrl$Mean_mut_percentage[internal_ctrl$Mean_mut_percentage < 0] <- 0
internal_ctrl$Ref_base <- toupper(internal_ctrl$Ref_base)
internal_ctrl$Ref_base <- gsub("T", "U", internal_ctrl$Ref_base)

summary <- c("A","C","G","U")

for (SL5_70C in SL5_70Cs$Sample) {
  
  sample <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", SL5_70C), header = TRUE)
  sample <- sample[c("Region", "Position", "Ref_base", "Mut_percentage")]
  sample$Mut_percentage[sample$Mut_percentage < 0] <- 0
  sample$Ref_base <- toupper(sample$Ref_base)
  sample$Ref_base <- gsub("T", "U", sample$Ref_base)
  
  difference <- add_columns(sample, internal_ctrl, by=c("Region", "Position", "Ref_base"))
  colnames(difference) <- c("Region", "Position", "Ref_base", "Mut_percentage", "Mut_percentage_ctrl")
  difference <- mutate(difference, Difference = Mut_percentage - Mut_percentage_ctrl)
  
  a <- filter(difference, Ref_base == "A")
  a <- round(mean(a$Difference),4)
  c <- filter(difference, Ref_base == "C")
  c <- round(mean(c$Difference),4)
  g <- filter(difference, Ref_base == "G")
  g <- round(mean(g$Difference),4)
  u <- filter(difference, Ref_base == "U")
  u <- round(mean(u$Difference),4)
  summary <- data.frame(summary,c(a,c,g,u))
  
}
names <- basename(SL5_70Cs$Group)
colnames(summary) <- c("Base", names)
write.table(summary, file=paste0("./3.analysis/8.spreadsheets/5.summary/SL5_70C.csv"), sep=",", row.names = FALSE)
sum70 <- summary

################################################################################

# calculate net mut percentage
csvs <- list.files(path='./3.analysis/8.spreadsheets/5.summary/', pattern='*.mpileup.csv', full.names = TRUE)
list <- read.csv("./3.analysis/8.spreadsheets/5.summary/list.csv", header = FALSE)
colnames(list) <- c("Sample", "Group")
samples <- unique(list$Sample)
groups <- unique(list$Group)

SL5_80Cs <- filter(list, grepl("80C-15min", list$Group))
internal_ctrl <- read.csv("./3.analysis/8.spreadsheets/5.summary/13_live-cell_DMSO_80C-15min_Mn.mean.csv", header = TRUE)
internal_ctrl <- internal_ctrl[c("Region", "Position", "Ref_base", "Mean_mut_percentage")]
internal_ctrl$Mean_mut_percentage[internal_ctrl$Mean_mut_percentage < 0] <- 0
internal_ctrl$Ref_base <- toupper(internal_ctrl$Ref_base)
internal_ctrl$Ref_base <- gsub("T", "U", internal_ctrl$Ref_base)

summary <- c("A","C","G","U")

for (SL5_80C in SL5_80Cs$Sample) {
  
  sample <- read.csv(paste0("./3.analysis/8.spreadsheets/5.summary/", SL5_80C), header = TRUE)
  sample <- sample[c("Region", "Position", "Ref_base", "Mut_percentage")]
  sample$Mut_percentage[sample$Mut_percentage < 0] <- 0
  sample$Ref_base <- toupper(sample$Ref_base)
  sample$Ref_base <- gsub("T", "U", sample$Ref_base)
  
  difference <- add_columns(sample, internal_ctrl, by=c("Region", "Position", "Ref_base"))
  colnames(difference) <- c("Region", "Position", "Ref_base", "Mut_percentage", "Mut_percentage_ctrl")
  difference <- mutate(difference, Difference = Mut_percentage - Mut_percentage_ctrl)
  
  a <- filter(difference, Ref_base == "A")
  a <- round(mean(a$Difference),4)
  c <- filter(difference, Ref_base == "C")
  c <- round(mean(c$Difference),4)
  g <- filter(difference, Ref_base == "G")
  g <- round(mean(g$Difference),4)
  u <- filter(difference, Ref_base == "U")
  u <- round(mean(u$Difference),4)
  summary <- data.frame(summary,c(a,c,g,u))
  
}
names <- basename(SL5_80Cs$Group)
colnames(summary) <- c("Base", names)
write.table(summary, file=paste0("./3.analysis/8.spreadsheets/5.summary/SL5_80C.csv"), sep=",", row.names = FALSE)
sum80 <- summary

################################################################################

# Read your data
df <- read.table("./3.analysis/8.spreadsheets/5.summary/summary.csv", header = TRUE, sep = ",", check.names = FALSE)

# Reshape from wide to long format
df_long <- df %>%
  pivot_longer(cols = c("40", "50", "60", "70", "80"),
               names_to = "Condition",
               values_to = "Value") %>%
  mutate(Condition = as.numeric(Condition))

# Set factor levels for Group (controls order and legend)
df_long$Group <- factor(df_long$Group, levels = c("C12_A", "C12_C", "C12_G", "C12_U",
                                                  "C30_A", "C30_C", "C30_G", "C30_U"))

# Define custom colors
group_colors <- c(
  "C12_A" = "#1F77B4",
  "C12_C" = "#FF7F0E",
  "C12_G" = "#2CA02C",
  "C12_U" = "#D62728",
  "C30_A" = "#1F77B4",
  "C30_C" = "#FF7F0E",
  "C30_G" = "#2CA02C",
  "C30_U" = "#D62728"
)

# Define shapes: circle (16) for C12 groups, triangle (17) for C30 groups
shape_values <- c(
  "C12_A" = 16,
  "C12_C" = 16,
  "C12_G" = 16,
  "C12_U" = 16,
  "C30_A" = 17,
  "C30_C" = 17,
  "C30_G" = 17,
  "C30_U" = 17
)

# Calculate mean values per Group and Condition
df_means <- df_long %>%
  group_by(Group, Condition) %>%
  summarise(Mean = mean(Value), .groups = "drop")

# Plot
p <- ggplot(df_long, aes(x = Condition, y = Value, color = Group, shape = Group)) +
  geom_point(alpha = 0.2, size = 3) +
  geom_smooth(se = FALSE, method = "loess", linewidth = 0.8) +
  geom_point(data = df_means, aes(x = Condition, y = Mean, color = Group, shape = Group), 
             alpha = 0.8, size = 3) +
  scale_color_manual(values = group_colors) +
  scale_shape_manual(values = shape_values) +
  coord_cartesian(xlim = c(38, 82), ylim = c(-0.02, 0.45)) +
  annotate("text", x = 65.2, y = -0.02, label = "(Each group has two replicates)", 
           hjust = 0, size = 3, color = "gray40") +
  theme_minimal(base_size = 14) +
  ggtitle("Mutation Rate - Temperature Gradient Summary") +
  theme(
    plot.title = element_text(hjust = 0.5),
    legend.position = "right"
  ) +
  labs(x = "\nTemperature (°C)", y = "Mutation rate % (normalized to DMSO control)\n",
       shape = "Group", color = "Group")

# Save
ggsave("./3.analysis/9.plots/8.temp_gradient/smooth_summary.pdf", plot = p, width = 9, height = 8, units = "in", dpi = 1200)
ggsave("./3.analysis/9.plots/8.temp_gradient/smooth_summary.jpg", plot = p, width = 9, height = 8, units = "in", dpi = 1200)

# cleanup
rm(list = ls())
